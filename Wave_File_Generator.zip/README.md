# Wave File Generator
## We implemented version (A, B , and C) and we would like C to be graded.
## In order to compile the program type in the following in the terminal:

``` bash
g++ waveC.cpp -o waveC
```
and the to run it, you need to have a text file that has the notes and the info as described in the assignment. And you can run:

``` bash 
./waveC <file_name.txt>
```

This will generate a .wav file that you can playback.

